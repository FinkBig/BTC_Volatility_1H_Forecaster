from PIL import Image, ImageDraw, ImageFont
import io
from datetime import datetime

def create_result_image(crypto, current_price, T_days, option_side, iv, strike_prices, fair_values):
    """Creates a clean PNG image with calculation results"""
    # Create image with white background
    width = 800
    height = 600
    background_color = (255, 255, 255)
    text_color = (33, 33, 33)
    header_color = (0, 102, 204)
    
    image = Image.new('RGB', (width, height), background_color)
    draw = ImageDraw.Draw(image)
    
    try:
        # Try to use a nice font if available
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24)
        regular_font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
    except:
        # Fallback to default font
        font = ImageFont.load_default()
        regular_font = ImageFont.load_default()

    # Draw title
    title = f"{crypto.upper()} Options Calculator Results"
    draw.text((40, 40), title, font=font, fill=header_color)
    
    # Draw timestamp
    timestamp = f"Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"
    draw.text((40, 80), timestamp, font=regular_font, fill=text_color)
    
    # Draw input parameters
    y = 140
    inputs = [
        f"Current Price: ${current_price:,.2f}",
        f"Time to Expiry: {T_days} days",
        f"Option Type: {option_side}",
        f"Implied Volatility: {iv*100:.1f}%"
    ]
    
    draw.text((40, y), "Input Parameters:", font=font, fill=header_color)
    y += 40
    for input_text in inputs:
        draw.text((60, y), input_text, font=regular_font, fill=text_color)
        y += 30
        
    # Draw results table
    y += 20
    draw.text((40, y), "Fair Value Results:", font=font, fill=header_color)
    y += 40
    
    # Table headers
    draw.text((60, y), "Strike Price", font=regular_font, fill=text_color)
    draw.text((300, y), "Fair Value", font=regular_font, fill=text_color)
    y += 30
    
    # Draw line under headers
    draw.line([(60, y), (500, y)], fill=text_color, width=1)
    y += 10
    
    # Table rows
    for strike_price, fair_value in zip(strike_prices, fair_values):
        draw.text((60, y), f"${strike_price:,.2f}", font=regular_font, fill=text_color)
        draw.text((300, y), f"{fair_value*100:.2f}%", font=regular_font, fill=text_color)
        y += 30
        
    # Convert to bytes
    img_byte_array = io.BytesIO()
    image.save(img_byte_array, format='PNG')
    img_byte_array.seek(0)
    return img_byte_array.getvalue()
