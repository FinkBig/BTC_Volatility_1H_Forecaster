import requests
import numpy as np
from math import log, sqrt
from scipy.stats import norm

def fetch_current_price(crypto):
    """
    Fetches the current price of a cryptocurrency from CoinGecko API.
    """
    crypto_map = {'eth': 'ethereum', 'btc': 'bitcoin'}
    
    if crypto in crypto_map:
        crypto = crypto_map[crypto]
    
    url = f'https://api.coingecko.com/api/v3/simple/price?ids={crypto}&vs_currencies=usd'
    try:
        response = requests.get(url)
        data = response.json()
        if response.status_code == 200 and crypto in data:
            return data[crypto]['usd']
        else:
            return None
    except Exception:
        return None

def validate_strike_prices(strike_prices_str):
    """
    Validates and converts strike prices string to list of floats
    """
    try:
        prices = [float(price.strip()) for price in strike_prices_str.split(',')]
        if all(price > 0 for price in prices):
            return prices
    except ValueError:
        pass
    return None
