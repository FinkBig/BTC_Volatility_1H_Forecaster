from sqlalchemy import create_engine, Column, Integer, Float, String, DateTime, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from datetime import datetime

# Get database URL from environment variable
DATABASE_URL = os.getenv('DATABASE_URL')

# Create SQLAlchemy engine and session
engine = create_engine(DATABASE_URL)
Session = sessionmaker(bind=engine)
Base = declarative_base()

class CalculationHistory(Base):
    """Model for storing option calculation history"""
    __tablename__ = 'calculation_history'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    cryptocurrency = Column(String)
    current_price = Column(Float)
    strike_prices = Column(JSON)  # Store as JSON array
    time_to_expiry = Column(Integer)  # in days
    option_type = Column(String)
    implied_volatility = Column(Float)
    fair_values = Column(JSON)  # Store as JSON dictionary

def init_db():
    """Initialize the database by creating all tables"""
    Base.metadata.create_all(engine)

def save_calculation(crypto, current_price, strike_prices, T_days, option_side, iv, fair_prices):
    """Save a calculation to the database"""
    session = Session()
    try:
        calc = CalculationHistory(
            cryptocurrency=crypto,
            current_price=current_price,
            strike_prices=strike_prices,
            time_to_expiry=T_days,
            option_type=option_side,
            implied_volatility=iv,
            fair_values=fair_prices
        )
        session.add(calc)
        session.commit()
        return True
    except Exception as e:
        print(f"Error saving calculation: {e}")
        session.rollback()
        return False
    finally:
        session.close()

def get_recent_calculations(limit=10):
    """Get recent calculations from the database"""
    session = Session()
    try:
        return session.query(CalculationHistory)\
            .order_by(CalculationHistory.timestamp.desc())\
            .limit(limit)\
            .all()
    except Exception as e:
        print(f"Error fetching calculations: {e}")
        return []
    finally:
        session.close()
