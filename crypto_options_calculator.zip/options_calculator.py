import numpy as np
from math import log, sqrt
from scipy.stats import norm

def lognormal_finish_probability(S, K, T, sigma, option_side='CALL', r=0.0):
    """
    Calculates the probability of finishing in-the-money using the Black-Scholes model.
    """
    if T <= 0 or sigma <= 0 or S <= 0 or K <= 0:
        return np.nan
        
    X0 = log(S)
    mu = r - 0.5 * sigma**2
    mean_XT = X0 + mu * T
    std_XT = sigma * sqrt(T)
    a = log(K)
    
    if option_side.upper() == 'CALL':
        z_up = (a - mean_XT) / std_XT
        return 1.0 - norm.cdf(z_up)
    elif option_side.upper() == 'PUT':
        z_down = (a - mean_XT) / std_XT
        return norm.cdf(z_down)
    else:
        return np.nan

def calculate_fair_value(S, strike_prices, T, option_side, iv):
    """
    Calculates the fair market value of binary one-touch options.
    """
    if S is None:
        return None

    fair_prices = {}
    for strike_price in strike_prices:
        fair_price = lognormal_finish_probability(S, strike_price, T, iv, option_side)
        fair_prices[strike_price] = fair_price

    return fair_prices
