import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from utils import fetch_current_price, validate_strike_prices
from options_calculator import calculate_fair_value
from models import init_db, save_calculation, get_recent_calculations
from image_generator import create_result_image
import json
import base64
from io import BytesIO

# Initialize database
init_db()

def create_results_chart(strike_prices, fair_prices, current_price, crypto, option_side):
    """Creates a plotly chart showing strike prices and fair values"""
    fig = go.Figure()

    # Add fair values line with improved styling
    fig.add_trace(go.Scatter(
        x=strike_prices,
        y=[fair_prices[k] * 100 for k in strike_prices],
        mode='lines+markers',
        name='Fair Value (%)',
        line=dict(color='#2E86C1', width=3),
        marker=dict(size=8, symbol='circle')
    ))

    # Add vertical line for current price with improved styling
    fig.add_vline(
        x=current_price,
        line_dash="dash",
        line_color="#E74C3C",
        line_width=2,
        annotation_text=f"Current Price: ${current_price:,.2f}",
        annotation_position="top right"
    )

    fig.update_layout(
        title=dict(
            text=f'{crypto.upper()} {option_side} Option Fair Values',
            x=0.5,
            xanchor='center',
            font=dict(size=24)
        ),
        xaxis_title='Strike Price ($)',
        yaxis_title='Fair Value (%)',
        hovermode='x',
        paper_bgcolor='white',
        plot_bgcolor='rgba(240,240,240,0.5)',
        font=dict(size=14),
        showlegend=True,
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01,
            bgcolor='rgba(255,255,255,0.8)'
        )
    )

    # Add grid and improve axis styling
    fig.update_xaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.2)', tickformat="$,.0f")
    fig.update_yaxes(showgrid=True, gridwidth=1, gridcolor='rgba(128,128,128,0.2)', tickformat=".1f")

    return fig

def create_copy_button(b64_img, button_text="Copy Image"):
    """Creates a button that copies an image to clipboard using JavaScript"""
    js_code = f"""
    <button onclick="copyImage()" style="
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        border-radius: 4px;">
        📋 {button_text}
    </button>
    <script>
    async function copyImage() {{
        try {{
            const response = await fetch('data:image/png;base64,{b64_img}');
            const blob = await response.blob();
            await navigator.clipboard.write([
                new ClipboardItem({{'image/png': blob}})
            ]);
            alert('Image copied to clipboard!');
        }} catch (err) {{
            console.error('Failed to copy image:', err);
            alert('Failed to copy image. Please try downloading instead.');
        }}
    }}
    </script>
    """
    return js_code

def display_calculation_history():
    """Display recent calculation history"""
    st.subheader("Recent Calculations")

    recent_calcs = get_recent_calculations()
    if not recent_calcs:
        st.info("No calculation history available")
        return

    for calc in recent_calcs:
        with st.expander(f"{calc.cryptocurrency.upper()} {calc.option_type} - {calc.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"):
            # Generate image for historical calculation
            img_bytes = create_result_image(
                calc.cryptocurrency,
                calc.current_price,
                calc.time_to_expiry,
                calc.option_type,
                calc.implied_volatility,
                calc.strike_prices,
                [calc.fair_values[str(k)] for k in calc.strike_prices]
            )

            # Convert image to base64
            b64_img = base64.b64encode(img_bytes).decode()

            # Display image and copy button
            st.markdown(f'<img src="data:image/png;base64,{b64_img}" style="width:100%">', unsafe_allow_html=True)
            st.markdown(create_copy_button(b64_img, "Copy This Calculation"), unsafe_allow_html=True)

def main():
    st.set_page_config(
        page_title="Crypto Options Calculator",
        layout="wide",
        initial_sidebar_state="expanded"
    )

    st.title("Cryptocurrency Options Calculator")
    st.markdown("""
    This calculator helps determine fair market values for cryptocurrency options based on various parameters.
    Enter the required information below to calculate option values.
    """)

    # Create two columns for input
    col1, col2 = st.columns(2)

    with col1:
        crypto = st.selectbox(
            "Select Cryptocurrency",
            options=['eth', 'btc'],
            format_func=lambda x: x.upper()
        )

        strike_prices_str = st.text_input(
            "Enter Strike Prices (comma-separated)",
            help="Example: 2000,2100,2200"
        )

        T_days = st.number_input(
            "Time to Expiry (days)",
            min_value=1,
            value=30
        )

    with col2:
        option_side = st.selectbox(
            "Option Type",
            options=['CALL', 'PUT']
        )

        iv = st.number_input(
            "Implied Volatility (%)",
            min_value=1.0,
            max_value=200.0,
            value=50.0,
            step=0.1,
            help="Enter implied volatility as a percentage"
        ) / 100

    # Calculate button
    if st.button("Calculate Fair Values"):
        current_price = fetch_current_price(crypto)
        strike_prices = validate_strike_prices(strike_prices_str)

        if current_price is None:
            st.error("Error fetching current price. Please try again later.")
        elif strike_prices is None:
            st.error("Invalid strike prices. Please enter comma-separated positive numbers.")
        else:
            T = T_days / 365  # Convert days to years
            fair_prices = calculate_fair_value(current_price, strike_prices, T, option_side, iv)

            if fair_prices:
                # Save calculation to database
                save_calculation(
                    crypto, 
                    current_price, 
                    strike_prices, 
                    T_days, 
                    option_side, 
                    iv, 
                    {str(k): v for k, v in fair_prices.items()}
                )

                # Create results container
                st.container()

                # Display current price with metric
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Current Price", f"${current_price:,.2f}")
                with col2:
                    st.metric("Time to Expiry", f"{T_days} days")
                with col3:
                    st.metric("Implied Volatility", f"{iv*100:.1f}%")

                # Create results dataframe
                results_df = pd.DataFrame({
                    'Strike Price': strike_prices,
                    'Fair Value (%)': [fair_prices[k] * 100 for k in strike_prices]
                })

                # Display results in tabs
                tab1, tab2, tab3 = st.tabs(["📊 Chart", "📑 Results", "📋 Quick Share"])

                with tab1:
                    st.plotly_chart(
                        create_results_chart(strike_prices, fair_prices, current_price, crypto, option_side),
                        use_container_width=True
                    )

                with tab2:
                    st.dataframe(
                        results_df.style.format({
                            'Strike Price': '${:,.2f}',
                            'Fair Value (%)': '{:.2f}%'
                        }),
                        use_container_width=True
                    )

                with tab3:
                    # Generate image of results
                    img_bytes = create_result_image(
                        crypto, 
                        current_price, 
                        T_days, 
                        option_side, 
                        iv, 
                        strike_prices, 
                        [fair_prices[k] for k in strike_prices]
                    )

                    # Convert image to base64 for display
                    b64_img = base64.b64encode(img_bytes).decode()

                    st.markdown("### Share Results")
                    st.markdown("Click the button below to copy the results to your clipboard:")

                    # Display image and copy button
                    st.markdown(f'<img src="data:image/png;base64,{b64_img}" style="width:100%">', unsafe_allow_html=True)
                    st.markdown(create_copy_button(b64_img), unsafe_allow_html=True)

            else:
                st.error("Error calculating fair values. Please check your inputs.")

    # Display calculation history
    display_calculation_history()

if __name__ == "__main__":
    main()